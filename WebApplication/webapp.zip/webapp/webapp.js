    // set up ========================
    var express  = require('express');
    var app      = express();                              
    var morgan = require('morgan');
    var http = require('http').createServer(app); 
    var bodyParser = require('body-parser');    
    var methodOverride = require('method-override'); 
    var mqtt    = require('mqtt');
    var getIP = require('ipware')().get_ip;
    var kafkaesque = require('kafkaesque')({
    brokers: [{host: '52.53.180.39', port: 9092}],
    clientId: 'test',
    maxBytes: 2000000
    });

    //var client = mqtt.connect({ host: '52.53.195.56', port: 1883 });
    var client = mqtt.connect({ host: '52.26.17.88', port: 1883 });
    client.subscribe('sensorState');
    client.subscribe('sensorTemp');
    client.subscribe('sensorHumidity');
    //web server
    app.set('port', process.env.PORT || 8080);
    app.use(express.static(__dirname + '/public'));                 // set the static files location /public/img will be /img for users
    app.use(morgan('dev'));                                         // log every request to the console
    app.use(bodyParser.urlencoded({'extended':'true'}));            // parse application/x-www-form-urlencoded
    app.use(bodyParser.json());                                     // parse application/json
    app.use(bodyParser.json({ type: 'application/vnd.api+json' })); // parse application/vnd.api+json as json
    app.use(methodOverride());
    app.use(function(req,res,next){
        var ipinfo = getIP(req);
        console.log(ipinfo);
        next();
    })
    //var msg = {"SensorState": "on", "Temperature": 25, "Humidity": 23};
    //var counterui = 0;
    //var notificationArr = [];
    //var notify = {"NotifyCount": 0, "NotifyVal": []};
    var msg;
    var current_temp;
    var current_humidity;
    client.on('message', function(topic, message, packet) {
            //console.log("MQTT Incoming message : " + message);
            if(topic == "sensorState")
            {
                msg = message;
                //console.log("Message received on sensorData Topic" + JSON.parse(msg));
            }
            if(topic == "sensorTemp")
            {
                current_temp = message;
            }
            if(topic == "sensorHumidity")
            {
                current_humidity = message;
            }

        }); 
   
    app.get('/api/statedata', function(req, res) {
        //console.log("Sending data on /api/data -" + msg);
        res.send(msg); 
    });

    app.get('/api/tempdata', function(req, res) {
        res.send(current_temp); 
    });

    app.get('/api/humiditydata', function(req, res) {
        res.send(current_humidity); 
    });

    app.post('/api/button', function(req, res) {
        //console.log("Received Post request for sensor state");
        var x = JSON.stringify(req.body.btnState); 
        client.publish('SetSensorState',x);        
        //console.log(req.body);
        res.header("Access-Control-Allow-Origin", "*");
        res.send("OK");
    });

    app.post('/api/currentDate', function(req, res) {
        var x = req.body; 
        //console.log(req.body);
        kafkaesque.tearUp(function() {
            var prediction_message = JSON.parse('{"predict": ""}');
            prediction_message.predict = x
            kafkaesque.produce({topic: 'currentTimeArr', partition: 0}, 
                      //['2', '33'],
                      [JSON.stringify(prediction_message)],
                     function(err, response) {
                    console.log(response);
            kafkaesque.tearDown();
            });
        });


        res.header("Access-Control-Allow-Origin", "*");
        res.send("OK");
    });

    app.post('/api/thermotemp', function(req, res) {
        console.log("successful POST" + JSON.stringify(req.body));

        //var x = JSON.stringify(req.body.set_temp); 
        var x = req.body.set_temp;
        client.publish('SetTemperature',x);        
        //console.log(req.body.temp);
        res.header("Access-Control-Allow-Origin", "*");
        res.send("OK");
    });
 
    http.listen(app.get('port'), function() {
        console.log('Express server listening on port ' + app.get('port'));
    });