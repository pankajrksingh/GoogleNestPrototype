var sensor = angular.module('app', ['ngSanitize','toggle-switch', 'ui-notification','angular.less']);
sensor.controller('mainController', function ($scope, $http, Notification, $interval) {

        $scope.tempData = 0;
        $scope.humidityData = 0;
      $scope.init = function () {
        $http.get('/api/statedata')
        .success(function(response) {
          $scope.sensorData = response;
             if($scope.sensorData.SensorState == 'False'){
              $scope.switchStatus = false;
              }
            else
            {
            $scope.switchStatus = true;
            }
        })
        .error(function(data) {
            console.log('Error in /api/statedata: ' + data);
          });   
        var d = new Date();
        var currentMin = parseInt(moment(d).format('hhmm')); 
        //var currentMin = new Date().getHours() + new Date().getMinutes(); 
        var arr = [];
        for (var i = 0; i < 5; i++) {
          var arrVal = currentMin + i*100;
/*          if(arrVal > 1440){
            arrVal = arrVal - 1440;
          }*/
          var a = arrVal;
          arr.push(a);
        }
       //var date = {"timeInHours" : arr};
       $http.post('/api/currentDate', arr)
        .success(function(data) {
                console.log("24 hours time sent to server");
        })
        .error(function(data) {
                console.log('Error: ' + data);
        });

      }

      $scope.init();

      $scope.getIP = function(){
        return 
      }        

        //GET Request OpenWeatherAPI
        $scope.getWeather = function(){   
        //$scope.IPinfo = $scope.getIP();
        $http(
          { url: "http://ipinfo.io/json",
            method: "JSONP",
            params: {callback:"JSON_CALLBACK"}
          }
          ).success(function(response) {
          console.log("IP Info Data : " + JSON.stringify(response));
          $scope.unitinput = 'C'; //C or F
          if($scope.unitinput == 'C'){var parsedUnits = 'metric';}
          else{var parsedUnits = 'imperial';}
          var latitude = response.loc.split(',')[0];
          var longitude = response.loc.split(',')[1];
          var ApiID = '8f30557f68cb6e27ea49931c789f6374';
          var callback_METHOD = 'JSON_CALLBACK'; 
           $http(
          { url: "http://api.openweathermap.org/data/2.5/weather?",
           method: "JSONP",
           params: {units: parsedUnits,
                    lat: latitude,
                    lon: longitude,
                    appid: ApiID,
                    callback: callback_METHOD
                      } }
          ).success(function(response) {
          console.log("Weather Data : " + JSON.stringify(response));
          $scope.city = response.name;
          $scope.country = response.sys.country;
          $scope.currentTemperature = response.main.temp;
          $scope.currentWeather = response.weather[0].main;

          var weatherCode = response.weather[0].id;
          //var weatherCode = Math.floor(Math.random() * 1000) + 200

        if (weatherCode >= 200 && weatherCode < 300) {
            $scope.weatherClass = 'thunderstorm';
        } else if (weatherCode >= 300 && weatherCode < 400) {
            $scope.weatherClass = 'drizzle';
        } else if (weatherCode >= 500 && weatherCode < 600) {
            $scope.weatherClass = 'rain';
        } else if (weatherCode >= 600 && weatherCode < 700) {
            $scope.weatherClass = 'snow';
        } else if (weatherCode >= 700 && weatherCode < 800) {
            $scope.weatherClass = 'atmosphere';
        } else if (weatherCode  === 800) {
            $scope.weatherClass = 'clear';
        } else if (weatherCode >= 801 && weatherCode < 900) {
            $scope.weatherClass = 'clouds';
        } else if (weatherCode >= 900 && weatherCode < 907) {
            $scope.weatherClass = 'extreme';
        } else if (weatherCode >= 907 && weatherCode < 1000) {
            $scope.weatherClass = 'additional';
        } else {
            $scope.weatherClass = 'unknown';
        }

        //$scope.weatherClass = 'clear';
        console.log("$scope.weatherClass : " + $scope.weatherClass);

        //$scope.weatherClass = 'atmosphere';
/*          return response;

*/        })
        .error(function(data) {
            console.log('Error: ' + data);
          });
          //$scope.IPData=response;
        })
        .error(function(data) {
            console.log('Error: ' + data);
            //$scope.IPData=data;
          });        
      }
      console.log("Weather Information : " + JSON.stringify($scope.getWeather()));
        $scope.sendState = function(val){
          var b = {"btnState" : val};
          console.log("Current Button state is: " + val);
          $http.post('/api/button', b)
            .success(function(data) {
                $scope.button = data;
            })
            .error(function(data) {
                console.log('Error: ' + data);
            });
        }

      $scope.sensorCall = function(){
        $http.get('/api/tempdata')
        .success(function(response) {
          $scope.sensorData = response;
          console.log("Data received is : " + response);
          //if($scope.sensorData.hasOwnProperty("Temperature")){
            $scope.tempData = $scope.sensorData.Temperature;
/*          }
          if ($scope.sensorData.hasOwnProperty("Humidity")) {
            $scope.humidityData = $scope.sensorData.Humidity;
          } */            
        })
        .error(function(data) {
            console.log('Error in /api/tempdata: ' + data);
          });

        $http.get('/api/humiditydata')
        .success(function(response) {
          $scope.sensorData = response;
          console.log("Data received is : " + response);
          /*if($scope.sensorData.hasOwnProperty("Temperature")){
            $scope.tempData = $scope.sensorData.Temperature;
          }
          if ($scope.sensorData.hasOwnProperty("Humidity")) {*/
            $scope.humidityData = $scope.sensorData.Humidity;
          //}             
        })
        .error(function(data) {
            console.log('Error in /api/humiditydata: ' + data);
          });
      };
      $interval($scope.sensorCall, 1000);
     

  });
    
    function Threshold(current) {
    var thrs = current;

    this.__defineGetter__("thrs", function () {
        return thrs;
    });

    this.__defineSetter__("thrs", function (val) {        
        val = parseInt(val);
        thrs = val;
    });
  }